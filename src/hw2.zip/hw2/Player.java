package hw2;
public interface Player {
	
	/**
	 * Prompts players to make a legal move.
	 * @return
	 */
	Board takeTurn(Board currentBoard);
	
	int calculateScore(Board currentBoard);
}
